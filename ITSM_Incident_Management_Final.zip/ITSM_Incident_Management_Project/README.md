
# ITSM Incident Management Using Machine Learning

## Project Overview
This project uses Machine Learning to predict IT incident priorities.
The goal is to help IT support teams identify and prioritize incidents
more efficiently.

## Objectives
- Analyze IT incident data.
- Perform data cleaning and exploratory data analysis.
- Predict incident priority using Machine Learning.
- Compare Logistic Regression and Random Forest models.
- Evaluate model performance using classification metrics.
- Save the trained model and prediction results.

## Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- SQLAlchemy
- MySQL
- Joblib

## Machine Learning Models
1. Logistic Regression
2. Random Forest Classifier

## Project Structure
- Models/: Saved Machine Learning model and preprocessor.
- Results/: Prediction results, performance metrics, charts,
  findings, and recommendations.
- Reports/: Project reports.

## Important Notes
The current notebook analysis uses the first 1,000 records retrieved
from the database. Results may change when the full dataset is analyzed.

Priority classes with fewer than two records were excluded from the
stratified train-test split.

## Future Improvements
- Analyze the complete dataset.
- Develop incident-volume forecasting.
- Explore automatic incident categorization.
- Develop an application for incident priority prediction.
- Evaluate additional Machine Learning models.

## Author
Rithick M
